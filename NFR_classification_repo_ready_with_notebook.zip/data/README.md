# NFR Unified Synthetic Dataset (2,847 Requirements)

This dataset integrates **synthetic but realistic** non-functional requirements (NFRs) generated for research, benchmarking, and educational purposes.

## 📘 Overview
- **Total records:** 2,847
- **Categories:**
  - Performance (n = 487, 17.1%)
  - Security (n = 456, 16.0%)
  - Usability (n = 445, 15.6%)
  - Reliability (n = 434, 15.2%)
  - Maintainability (n = 423, 14.9%)
  - Portability (n = 602, 21.1%)
- **Schema:** `id, requirement_text, category, source_dataset, domain`
- **Source Labels:** synth_PROMISE, synth_NoRBERT, synth_NFRDeepLearning, synth_Rahman

## ⚙️ File Details
| File | Format | Description |
|------|---------|-------------|
| `nfr_unified_synthetic_2847_v2.csv` | CSV | For model training and data analysis |
| `nfr_unified_synthetic_2847_v2.xlsx` | Excel | For manual inspection and sharing |

## 🧠 Generation Methodology
The requirements were generated programmatically using domain-specific templates designed to resemble real NFR statements. Each record includes randomized parameters (e.g., latency, encryption algorithm, throughput, failure recovery time) and is contextualized with domain references (e.g., healthcare, finance, telecom).

This approach maintains realism while ensuring the dataset is **free of copyright or proprietary text**.

## 📊 Example Record
| id | requirement_text | category | domain |
|----|------------------|-----------|---------|
| NFR_0001 | In the healthcare domain, the system shall respond to user requests within 200 ms under 500 concurrent users. | Performance | healthcare |

## 🧾 License
This synthetic dataset is distributed under the **MIT License**. You may freely use, modify, and distribute it for academic or research purposes.

---
Generated for repository **nabotahmad-rgb / NFR-classification**.
