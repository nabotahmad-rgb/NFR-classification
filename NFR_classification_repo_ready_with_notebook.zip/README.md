# NFR Classification Project

This repository contains the dataset and experimental framework for **Non-Functional Requirements (NFR) classification** using modern NLP models (e.g., BERT, Hybrid T-RNN).

## 📂 Structure
```
NFR-classification/
 ├── data/
 │    ├── nfr_unified_synthetic_2847_v2.csv
 │    ├── nfr_unified_synthetic_2847_v2.xlsx
 │    └── README.md
 ├── models/
 ├── notebooks/
 └── README.md
```

## 📘 Dataset
The dataset in `/data` contains **2,847 synthetic NFR statements** covering six ISO/IEC 25010 categories:
Performance, Security, Usability, Reliability, Maintainability, and Portability.

## ⚙️ Usage
Example for loading in Python:
```python
import pandas as pd
df = pd.read_csv('data/nfr_unified_synthetic_2847_v2.csv')
print(df.head())
```

## 🧾 License
All synthetic data are provided under the **MIT License**.

---
Generated automatically for **nabotahmad-rgb / NFR-classification**.
