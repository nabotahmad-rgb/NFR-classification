# Quick Reference Card - NFR Classification

## 🔗 Repository Information

**Name**: NFR Classification Reproducibility Framework  
**GitHub**: https://github.com/nabot/rgb/NFR-classification  
**Team**: Nabot RGB Team  
**Focus**: Non-Functional Requirements Classification

---

## ⚡ Essential Commands

### Setup
```bash
git clone https://github.com/nabot/rgb/NFR-classification.git
cd NFR-classification
conda env create -f environment.yml
conda activate nfr-env
pip install -e .
```

### Run Experiments
```bash
# All experiments
bash scripts/run_all_experiments.sh

# Single experiment
python scripts/train_model.py --config configs/base_config.yaml --seed 42

# Ablation studies
bash scripts/run_ablation_studies.sh

# Validate results
python scripts/validate_results.py --results_dir results/main_experiments/
```

### Using Make
```bash
make install          # Install dependencies
make data            # Download and prepare data
make train           # Run main experiments
make ablations       # Run ablation studies
make validate        # Validate results
make figures         # Generate paper figures
make clean-all       # Clean everything
```

---

## 📁 Key Files

| File | Purpose |
|------|---------|
| `README.md` | Main documentation |
| `REPRODUCIBILITY.md` | Detailed instructions |
| `ABLATION_STUDIES.md` | Ablation documentation |
| `QUICKSTART.md` | 10-minute guide |
| `configs/base_config.yaml` | Main configuration |
| `scripts/run_all_experiments.sh` | Run everything |
| `results/published_results.json` | Reference results |

---

## 🎯 Project Specifics

### Names
- **Environment**: `nfr-env`
- **Package**: `nfr-classification`
- **Docker**: `nfr-classification:latest`
- **Containers**: `nfr-training`, `nfr-jupyter`, `nfr-tensorboard`

### Repository
- **Path**: `nabot/rgb/NFR-classification`
- **URL**: https://github.com/nabot/rgb/NFR-classification

---

## 📊 Expected Results

| Model | Accuracy | Status |
|-------|----------|--------|
| Baseline | 88.2±0.4% | Published |
| Main Model | 92.5±0.3% | Published |
| Ensemble | 93.1±0.2% | Published |

**Tolerance**: ±0.5% acceptable for reproduction

---

## 🐛 Common Issues & Solutions

### CUDA Out of Memory
```bash
python scripts/train_model.py --batch_size 32
```

### Different Results
```bash
python scripts/verify_determinism.py
```

### Slow Training
Edit `configs/base_config.yaml` and set `cudnn_benchmark: true`

---

## 📦 Files to Customize Before Upload

- [ ] `[your.email@institution.edu]` → Your email
- [ ] `[Funding Source]` → Actual funding
- [ ] `[Organization]` → Dataset provider
- [ ] ArXiv link → Actual paper URL
- [ ] Zenodo DOI → Actual DOI
- [ ] Author names in LICENSE
- [ ] Actual accuracy numbers
- [ ] Paper title in citations

---

## 📞 Quick Links

- **Issues**: https://github.com/nabot/rgb/NFR-classification/issues
- **Discussions**: https://github.com/nabot/rgb/NFR-classification/discussions
- **Docs**: `/docs` directory
- **Paper**: [Add link when available]

---

## 🎓 Citation

```bibtex
@article{nabot2025nfr,
  title={NFR Classification: A Comprehensive Analysis},
  author={Nabot RGB Team},
  year={2025}
}
```

---

**Print this card for quick reference!** 📋
