# Data Directory

This directory contains the NFR classification dataset.

## Structure

- `raw/` - Raw dataset files
- `processed/` - Preprocessed data ready for training
- `splits/` - Train/validation/test splits

## Usage

1. Download data: `bash scripts/download_data.sh`
2. Preprocess: `python scripts/preprocess_data.py --config configs/data_config.yaml`
