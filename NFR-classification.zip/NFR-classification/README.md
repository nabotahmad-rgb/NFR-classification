# NFR Classification: Reproducibility and Ablation Studies

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![PyTorch 2.0+](https://img.shields.io/badge/pytorch-2.0+-ee4c2c.svg)](https://pytorch.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![Tests](https://github.com/nabot/rgb/NFR-classification/workflows/Tests/badge.svg)](https://github.com/nabot/rgb/NFR-classification/actions)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

> **Full reproducibility framework for Non-Functional Requirements Classification**
> 
> 📄 [Paper](https://arxiv.org/abs/xxxx.xxxxx) | 📊 [Results](results/) | 🎯 [Models](models/) | 📖 [Docs](docs/)

---

## 🎯 Overview

This repository provides a **complete reproducibility framework** for our Non-Functional Requirements (NFR) classification research, including:

- ✅ **Full reproducibility** of all paper results (±0.5% accuracy)
- ✅ **7 comprehensive ablation studies** analyzing every component
- ✅ **One-command execution** for all experiments
- ✅ **Automated validation** against published results
- ✅ **Docker support** for environment consistency
- ✅ **Detailed documentation** with troubleshooting guides

### Key Results

| Model | Accuracy | Precision | Recall | F1 Score |
|-------|----------|-----------|--------|----------|
| Baseline | 88.2±0.4% | 87.9±0.5% | 88.1±0.4% | 88.0±0.4% |
| **Ours** | **92.5±0.3%** | **92.3±0.3%** | **92.4±0.3%** | **92.3±0.3%** |
| Ensemble | 93.1±0.2% | 93.0±0.2% | 93.1±0.2% | 93.0±0.2% |

---

## 🚀 Quick Start

### Installation (5 minutes)

```bash
# Clone repository
git clone https://github.com/nabot/rgb/NFR-classification.git
cd NFR-classification

# Setup environment (choose one)
conda env create -f environment.yml && conda activate nfr-env
# OR
pip install -r requirements.txt && pip install -e .

# Download and prepare data
bash scripts/download_data.sh
python scripts/preprocess_data.py --config configs/data_config.yaml
```

### Reproduce Main Results (3-24 hours)

```bash
# Single command to reproduce all paper results
bash scripts/run_all_experiments.sh

# Or run with multiple GPUs (faster)
bash scripts/run_all_experiments.sh --parallel --gpus 0,1,2,3

# Validate results
python scripts/validate_results.py \
    --results_dir results/main_experiments/ \
    --reference_file results/published_results.json
```

---

## 📊 Ablation Studies

Run comprehensive ablation studies:

```bash
# Run all ablation studies (48-72 hours)
bash scripts/run_ablation_studies.sh

# Or run specific ablation
bash scripts/run_ablation_studies.sh --ablation feature_selection
```

### Available Ablations

1. **Feature Selection** - Impact of different feature groups
2. **Model Architecture** - Effect of architectural choices
3. **Hyperparameters** - Sensitivity to hyperparameter variations
4. **Data Augmentation** - Contribution of augmentation techniques
5. **Preprocessing** - Impact of preprocessing steps
6. **Loss Functions** - Comparison of different loss functions
7. **Regularization** - Effectiveness of regularization methods

See [ABLATION_STUDIES.md](ABLATION_STUDIES.md) for detailed results.

---

## 📁 Repository Structure

```
NFR-classification/
├── README.md                  # This file
├── REPRODUCIBILITY.md         # Detailed reproducibility guide
├── ABLATION_STUDIES.md        # Ablation study documentation
├── QUICKSTART.md              # 10-minute quick start
├── requirements.txt           # Python dependencies
├── environment.yml            # Conda environment
├── setup.py                   # Package installation
├── Makefile                   # Convenient commands
├── Dockerfile                 # Docker setup
├── configs/                   # Configuration files
├── scripts/                   # Execution scripts
├── data/                      # Data directory
├── models/                    # Model implementations
├── training/                  # Training utilities
├── evaluation/                # Evaluation code
├── utils/                     # Utility functions
├── results/                   # Results directory
├── notebooks/                 # Jupyter notebooks
└── tests/                     # Unit tests
```

---

## 🔬 Documentation

- **[REPRODUCIBILITY.md](REPRODUCIBILITY.md)** - Complete reproducibility guide
- **[ABLATION_STUDIES.md](ABLATION_STUDIES.md)** - Detailed ablation analysis
- **[QUICKSTART.md](QUICKSTART.md)** - 10-minute quick start guide
- **[CONTRIBUTING.md](CONTRIBUTING.md)** - Contribution guidelines
- **[PAPER_CHECKLIST.md](PAPER_CHECKLIST.md)** - ML reproducibility checklist

---

## 💻 System Requirements

### Minimum Requirements
- **OS**: Linux, macOS, or Windows (with WSL2)
- **Python**: 3.8+
- **RAM**: 16GB
- **GPU**: NVIDIA GPU with 8GB VRAM
- **Storage**: 50GB

### Recommended Requirements
- **OS**: Linux (Ubuntu 20.04+)
- **Python**: 3.9
- **RAM**: 32GB+
- **GPU**: NVIDIA GPU with 16GB+ VRAM (V100, A100, RTX 3090/4090)
- **Storage**: 100GB+ SSD

---

## 🐳 Docker Support

```bash
# Build Docker image
docker build -t nfr-classification:latest .

# Run experiments in Docker
docker run --gpus all -it \
    -v $(pwd)/data:/workspace/data \
    -v $(pwd)/results:/workspace/results \
    nfr-classification:latest \
    bash scripts/run_all_experiments.sh

# Or use docker-compose
docker-compose up training
```

---

## 📈 Results Visualization

Generate all paper figures:

```bash
# Generate figures
python scripts/generate_paper_figures.py

# Generate tables
python scripts/generate_paper_tables.py

# Or use Jupyter notebooks
jupyter notebook notebooks/04_results_visualization.ipynb
```

---

## 🧪 Testing

```bash
# Run all tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=. --cov-report=html

# Check code quality
make lint
```

---

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Quick Contribution Steps
1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📝 Citation

If you use this code or dataset in your research, please cite:

```bibtex
@article{nabot2025nfr,
  title={NFR Classification: A Comprehensive Analysis},
  author={Nabot RGB Team and Collaborators},
  journal={Conference/Journal Name},
  year={2025},
  volume={XX},
  pages={XXX-XXX},
  doi={10.XXXX/XXXXX}
}
```

---

## 📜 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

The dataset is provided under [Dataset License]. Please cite the original dataset creators.

---

## 🙏 Acknowledgments

- Dataset provided by [Organization]
- Funded by [Funding Source]
- Computing resources from [Institution]
- Thanks to all contributors and reviewers

---

## 📧 Contact

- **Primary Contact**: [your.email@institution.edu]
- **Issues**: [GitHub Issues](https://github.com/nabot/rgb/NFR-classification/issues)
- **Discussions**: [GitHub Discussions](https://github.com/nabot/rgb/NFR-classification/discussions)

---

## 🔗 Links

- 📄 [ArXiv Paper](https://arxiv.org/abs/xxxx.xxxxx)
- 📊 [Papers with Code](https://paperswithcode.com/paper/nfr-classification)
- 🎯 [Pretrained Models](https://huggingface.co/nabot/nfr-classification)
- 📖 [Full Documentation](https://nabot.github.io/rgb/NFR-classification/)

---

## ⭐ Star History

If you find this work useful, please consider giving it a star! ⭐

---

<div align="center">

**Made with ❤️ by the Nabot RGB Team**

[⬆ Back to top](#nfr-classification-reproducibility-and-ablation-studies)

</div>
