# Results Directory

This directory stores experimental results.

## Structure

- `main_experiments/` - Main paper results
- `ablation_studies/` - Ablation study results
- `figures/` - Generated figures
- `tables/` - Generated tables
- `published_results.json` - Reference results for validation
