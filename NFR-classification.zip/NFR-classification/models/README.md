# Models Directory

This directory contains model architecture implementations.

## Files

- `architecture.py` - Main model definitions
- `base_model.py` - Base model class
- `loss_functions.py` - Custom loss functions
- `metrics.py` - Evaluation metrics
