# Quick Start Guide - NFR Classification

Get up and running with reproducibility experiments in 10 minutes!

## Prerequisites

- Linux/macOS/Windows with WSL2
- Python 3.9+
- CUDA-capable GPU (optional but recommended)
- 50GB free disk space

## Installation (5 minutes)

### Step 1: Clone Repository

```bash
git clone https://github.com/nabot/rgb/NFR-classification.git
cd NFR-classification
```

### Step 2: Setup Environment

**Option A: Conda (Recommended)**
```bash
conda env create -f environment.yml
conda activate nfr-env
```

**Option B: pip + venv**
```bash
python3.9 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### Step 3: Install Package

```bash
pip install -e .
```

### Step 4: Verify Installation

```bash
python -c "import nfr_classification; print('✓ Installation successful!')"
```

## Quick Test (2 minutes)

### Download Sample Data

```bash
# Download and prepare data
bash scripts/download_data.sh
python scripts/preprocess_data.py --config configs/data_config.yaml
```

### Run Quick Test

```bash
# Train a small model to verify everything works
python scripts/train_model.py \
    --config configs/base_config.yaml \
    --experiment_name quick_test \
    --seed 42
```

## Reproduce Main Results (3-24 hours)

```bash
# Single command to reproduce everything
bash scripts/run_all_experiments.sh

# Or with multiple GPUs (faster)
bash scripts/run_all_experiments.sh --parallel --gpus 0,1,2,3
```

## Run Ablation Studies (48-72 hours)

```bash
# Run all ablation studies
bash scripts/run_ablation_studies.sh

# Or specific ablation
bash scripts/run_ablation_studies.sh --ablation feature_selection
```

## Validate Results

```bash
python scripts/validate_results.py \
    --results_dir results/main_experiments/ \
    --reference_file results/published_results.json
```

Expected output:
```
✓ Baseline: 88.2% (published) vs 88.3% (yours) - PASS
✓ Main Model: 92.5% (published) vs 92.4% (yours) - PASS
✓ ALL VALIDATIONS PASSED
```

## Common Commands Cheat Sheet

```bash
# Setup
conda activate nfr-env

# Run main experiments
bash scripts/run_all_experiments.sh

# Run specific experiment
python scripts/train_model.py --config configs/base_config.yaml --seed 42

# Run ablations
bash scripts/run_ablation_studies.sh

# Validate results
python scripts/validate_results.py --results_dir results/main_experiments/

# Generate figures
python scripts/generate_paper_figures.py

# Check logs
tail -f logs/experiments.log

# Monitor GPU
watch -n 1 nvidia-smi
```

## Getting Help

- **Documentation**: Full docs in `docs/` directory
- **Issues**: [GitHub Issues](https://github.com/nabot/rgb/NFR-classification/issues)
- **Discussions**: [GitHub Discussions](https://github.com/nabot/rgb/NFR-classification/discussions)
- **Email**: your.email@institution.edu

---

**Ready to reproduce research? Start with:** `bash scripts/run_all_experiments.sh` 🚀
