#!/bin/bash
# Run All Main Experiments - Reproduces Paper Results

echo "Running NFR Classification Experiments"
echo "======================================="

# Run baseline
python scripts/train_model.py --config configs/base_config.yaml --experiment_name baseline --seed 42

# Run main model
python scripts/train_model.py --config configs/base_config.yaml --experiment_name main_model --seed 42

# Run ensemble
python scripts/train_model.py --config configs/base_config.yaml --experiment_name ensemble --seed 42

echo "All experiments completed!"
