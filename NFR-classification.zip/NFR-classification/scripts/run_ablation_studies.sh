#!/bin/bash
# Run All Ablation Studies

echo "Running Ablation Studies"
echo "========================"

# Run each ablation
python scripts/train_model.py --config configs/ablation_configs/ablation_feature_selection.yaml
python scripts/train_model.py --config configs/ablation_configs/ablation_model_architecture.yaml
python scripts/train_model.py --config configs/ablation_configs/ablation_hyperparameters.yaml

echo "All ablation studies completed!"
